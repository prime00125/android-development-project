package com.example.andro;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

public class MainActivity2 extends AppCompatActivity {

    Button b;
    EditText etn,etm,etp;
    RadioButton r1,r2;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        b=(Button) findViewById(R.id.btn);
        etn=(EditText) findViewById(R.id.t1);
        etm=(EditText) findViewById(R.id.t3);
        etp=(EditText) findViewById(R.id.t4);
        r1 = (RadioButton) findViewById (R.id.radio_one);
        r2 = (RadioButton) findViewById(R.id.radio_two);

        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final String email=etm.getText().toString();
                final String pass =etp.getText().toString();
                final String name =etn.getText().toString();
                String salute =" ";
                if(r1.isChecked())
                    salute="Male";
                else
                    salute="Female";
                Toast.makeText(MainActivity2.this,"clicked", Toast.LENGTH_LONG).show();
                System.out.println("name "+name +"\n email "+email+"\n pass "+pass+"\n Gender "+salute);
            }
        });
    }
}