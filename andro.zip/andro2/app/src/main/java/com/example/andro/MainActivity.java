package com.example.andro;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    EditText q1,q2;
    Button b;
    TextView ans;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        q1 = (EditText) findViewById(R.id.q1);
        q2 =  (EditText) findViewById(R.id.q2);
        b = (Button) findViewById(R.id.button);
        ans = (TextView) findViewById(R.id.textView3);
    }
    public void add(View v)
    {
        int i=Integer.parseInt(q1.getText().toString());
        int j=Integer.parseInt(q2.getText().toString());
        int k=i+j;
        ans.setText("ans is :"+k);
    }
}