package com.example.applo;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class ImgActivityActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.img_activity);
    }
}