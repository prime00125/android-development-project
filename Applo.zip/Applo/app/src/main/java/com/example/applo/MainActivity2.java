package com.example.applo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.Arrays;

public class MainActivity2 extends AppCompatActivity {

    ListView lv;
    Context con;

    public static Integer [] img1= {
            R.drawable.ic_launcher_background

    };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        lv =(ListView) findViewById(R.id.listview);
        final String val[]={"c","c++","java","R","scala","javascript","pro","android","go","pensula","dart","assembly","Vin","poi","tuy","ulu","amazon","netflix","hotstar"};
        ArrayAdapter adp=new ArrayAdapter(this, android.R.layout.simple_list_item_1, Arrays.asList(val));
        lv.setAdapter(adp);

        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Toast.makeText(MainActivity2.this,"u clicked on : "+val[i],Toast.LENGTH_SHORT).show();
            }
        });

    }
}