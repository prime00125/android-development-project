package com.example.applo;

import android.content.Context;
import android.database.DataSetObserver;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ExpandableListAdapter;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.util.List;
import java.util.Map;

public class MyExListAdapter implements ExpandableListAdapter
{

    Context context;
    List<String> lang;
    Map<String,List<String>> topic;

    public MyExListAdapter(Context context, List<String> lang, Map<String, List<String>> topic) {
        this.context = context;
        this.lang = lang;
        this.topic = topic;
    }

    @Override
    public void registerDataSetObserver(DataSetObserver dataSetObserver) {

    }

    @Override
    public void unregisterDataSetObserver(DataSetObserver dataSetObserver) {

    }

    @Override
    public int getGroupCount() {
        return lang.size();
    }

    @Override
    public int getChildrenCount(int i) {
        return topic.get(lang.get(i)).size();
    }

    @Override
    public Object getGroup(int i) {
        return lang.get(i);
    }

    @Override
    public Object getChild(int i, int i1) {
        return topic.get(lang.get(i)).get(i1);
    }

    @Override
    public long getGroupId(int i) {
        return i;
    }

    @Override
    public long getChildId(int i, int i1) {
        return i1;
    }

    @Override
    public boolean hasStableIds() {
        return false;
    }

    @Override
    public View getGroupView(int i, boolean b, View view, ViewGroup viewGroup) {
        String lang=(String)getGroup(i);
        if(view==null)
        {
            LayoutInflater inflater=(LayoutInflater) context.getSystemService(context.LAYOUT_INFLATER_SERVICE);
            view=inflater.inflate(R.layout.sublist,null);
        }
        TextView textparent=(TextView) view.findViewById(R.id.txt);
        textparent.setText(lang);
        return view;
    }

    @Override
    public View getChildView(int i, int i1, boolean b, View view, ViewGroup viewGroup) {
        String topic=(String)getChild(i,i1);
        if(view==null)
        {
            LayoutInflater inflater=(LayoutInflater) context.getSystemService(context.LAYOUT_INFLATER_SERVICE);
            view = inflater.inflate(R.layout.listchild,null);
        }
        TextView textchild=(TextView) view.findViewById(R.id.txt2);
        textchild.setText(topic);
        return view;
    }

    @Override
    public boolean isChildSelectable(int i, int i1) {
        return true;
    }

    @Override
    public boolean areAllItemsEnabled() {
        return false;
    }

    @Override
    public boolean isEmpty() {
        return false;
    }

    @Override
    public void onGroupExpanded(int i) {

    }

    @Override
    public void onGroupCollapsed(int i) {

    }

    @Override
    public long getCombinedChildId(long l, long l1) {
        return 0;
    }

    @Override
    public long getCombinedGroupId(long l) {
        return 0;
    }
}
