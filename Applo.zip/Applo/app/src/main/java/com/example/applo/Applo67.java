package com.example.applo;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ExpandableListAdapter;
import android.widget.ExpandableListView;
import android.widget.ListAdapter;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Applo67 extends AppCompatActivity {

    ExpandableListView elv;
    List<String > lang=new ArrayList<>();
    Map<String, List<String>> topic=new HashMap<String, List<String>>();
    ExpandableListAdapter listAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_applo67);

        elv=(ExpandableListView) findViewById(R.id.list);
        fillData();
        listAdapter=new MyExListAdapter(this,lang,topic);
        elv.setAdapter(listAdapter);
        elv.setOnChildClickListener(new ExpandableListView.OnChildClickListener() {
            @Override
            public boolean onChildClick(ExpandableListView expandableListView, View view, int i, int i1, long l) {
                Toast.makeText(Applo67.this,lang.get(i)+" : "+ topic.get(lang.get(i)).get(i1),Toast.LENGTH_SHORT).show();
                return true;
            }
        });
    }
    public void fillData()
    {
        lang.add("java");
        lang.add("c");

        List<String> java =new ArrayList<>();
        List<String> c=new ArrayList<>();

        java.add("super");
        java.add("encaplustion");
        java.add("methods");

        c.add("pointer");
        c.add("interface");
        c.add("union");

        topic.put(lang.get(0),java);
        topic.put(lang.get(1),c);

    }
}