package com.example.randomintgenerator;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    Button b;
    TextView t,output;
    EditText e1;


    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        b=(Button)    findViewById(R.id.btn);
        t=(TextView)  findViewById(R.id.t2);
        e1= (EditText) findViewById(R.id.e1);
        output=(TextView) findViewById(R.id.put);

        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int range = Integer.parseInt(e1.getText().toString());
                Random r=new Random();

                int randno =r.nextInt(range - 0)+0;
                output.setText(randno+" ");

            }
        });


    }
}