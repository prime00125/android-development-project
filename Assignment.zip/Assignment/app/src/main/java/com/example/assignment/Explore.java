package com.example.assignment;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.google.android.material.tabs.TabLayout;

public class Explore extends AppCompatActivity {
    TabLayout tab;
    ViewPager viewPager;
    Button btn;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_explore);

        tab=(TabLayout) findViewById(R.id.tab);
        viewPager=(ViewPager) findViewById(R.id.viewPager);

        viewPagerExploreAdapter adapter=new viewPagerExploreAdapter(getSupportFragmentManager());
        viewPager.setAdapter(adapter);
        tab.setupWithViewPager(viewPager);

        btn=(Button) findViewById(R.id.btn);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openMainActivity();
            }
        });

    }
    public void openMainActivity(){
        Intent intent=new Intent(Explore.this, MainActivity.class);
        startActivity(intent);
    }
}